CREATE FUNCTION obj_description(oid)
  RETURNS text
STABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select description from pg_catalog.pg_description where objoid = $1 and objsubid = 0
$$;

