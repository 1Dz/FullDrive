CREATE FUNCTION polygon(circle)
  RETURNS polygon
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.polygon(12, $1)
$$;

